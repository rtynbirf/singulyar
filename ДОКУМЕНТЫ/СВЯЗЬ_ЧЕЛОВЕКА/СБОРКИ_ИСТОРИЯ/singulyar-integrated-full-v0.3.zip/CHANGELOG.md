# CHANGELOG.md
## v0.3 Integrated Release (2026-10-14)
- Интегрирована Дверь ·53 СВЯЗЬ ЧЕЛОВЕКА в главный `index.html`.
- Создано отдельное P2P WebRTC приложение.
- Добавлен полный Python-движок ядра `singulyar_core.py`.
- Разработан валидатор пакета `tests/validate_bundle.py`.
