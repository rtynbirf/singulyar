"""
СИНГУЛЯР · Контур Человеческой Связи · Python Core Engine v0.3 Integrated
Единая программная реализация спецификаций 00-ARCHITECTURE...05-DECISIONS.
"""

import enum
import json
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

class DeliveryState(str, enum.Enum):
    DRAFT = "draft"
    LOCALLY_SAVED = "locally_saved"
    QUEUED = "queued"
    ATTEMPTING = "transport_attempted"
    ACCEPTED_BY_TRANSPORT = "accepted_by_transport"
    ACKNOWLEDGED_BY_RECIPIENT = "acknowledged_by_recipient"
    READ = "read"
    CANCELLED = "cancelled"
    FAILED = "failed"
    EXPIRED = "expired"

class IntentKind(str, enum.Enum):
    MESSAGE = "text"
    FILE = "file"
    VOICE = "voice"
    CALL_INVITE = "call_invite"
    VALUE_INTENT = "value_intent"
    CONTACT_INVITE = "contact_invite"

VALID_TRANSITIONS = {
    DeliveryState.DRAFT: [DeliveryState.LOCALLY_SAVED, DeliveryState.CANCELLED],
    DeliveryState.LOCALLY_SAVED: [DeliveryState.QUEUED, DeliveryState.CANCELLED],
    DeliveryState.QUEUED: [DeliveryState.ATTEMPTING, DeliveryState.CANCELLED],
    DeliveryState.ATTEMPTING: [DeliveryState.ACCEPTED_BY_TRANSPORT, DeliveryState.FAILED, DeliveryState.EXPIRED],
    DeliveryState.ACCEPTED_BY_TRANSPORT: [DeliveryState.ACKNOWLEDGED_BY_RECIPIENT, DeliveryState.FAILED],
    DeliveryState.ACKNOWLEDGED_BY_RECIPIENT: [DeliveryState.READ],
    DeliveryState.READ: [],
    DeliveryState.CANCELLED: [],
    DeliveryState.FAILED: [DeliveryState.QUEUED],
    DeliveryState.EXPIRED: [DeliveryState.QUEUED],
}

class Manifest:
    def __init__(self, payload: Any, mime_type: str = "text/plain", retention_policy: str = "local_only"):
        raw_bytes = json.dumps(payload, ensure_ascii=False).encode('utf-8') if not isinstance(payload, bytes) else payload
        self.size_bytes: int = len(raw_bytes)
        self.sha256_hash: str = hashlib.sha256(raw_bytes).hexdigest()
        self.mime_type: str = mime_type
        self.retention_policy: str = retention_policy

    def to_dict(self) -> Dict[str, Any]:
        return {
            "size_bytes": self.size_bytes,
            "sha256": self.sha256_hash,
            "mime_type": self.mime_type,
            "retention_policy": self.retention_policy
        }

class AuditRecord:
    def __init__(self, from_state: DeliveryState, to_state: DeliveryState, reason: str):
        self.timestamp: str = datetime.now(timezone.utc).isoformat()
        self.from_state: DeliveryState = from_state
        self.to_state: DeliveryState = to_state
        self.reason: str = reason

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "from": self.from_state.value,
            "to": self.to_state.value,
            "reason": self.reason
        }

class DeliveryStatus:
    def __init__(self):
        self.state: DeliveryState = DeliveryState.DRAFT
        self.idempotency_key: str = str(uuid.uuid4())
        self.history: List[AuditRecord] = []

    def transition_to(self, new_state: DeliveryState, reason: str):
        if new_state == self.state:
            return
        if new_state not in VALID_TRANSITIONS.get(self.state, []):
            raise ValueError(f"Invalid state transition: {self.state} -> {new_state}")
        record = AuditRecord(self.state, new_state, reason)
        self.state = new_state
        self.history.append(record)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "idempotency_key": self.idempotency_key,
            "audit_history": [r.to_dict() for r in self.history]
        }

class SingulyarObject:
    def __init__(self, kind: IntentKind, payload: Any, sender: str, recipient: str):
        self.schema: str = "singulyar.v0.1/object.json"
        self.id: str = str(uuid.uuid4())
        self.kind: IntentKind = kind
        self.createdAt: str = datetime.now(timezone.utc).isoformat()
        self.sender: str = sender
        self.recipient: str = recipient
        self.payload: Any = payload
        self.manifest: Manifest = Manifest(payload)
        self.delivery: DeliveryStatus = DeliveryStatus()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": self.schema,
            "id": self.id,
            "kind": self.kind.value,
            "createdAt": self.createdAt,
            "sender": self.sender,
            "recipient": self.recipient,
            "payload": self.payload,
            "manifest": self.manifest.to_dict(),
            "delivery": self.delivery.to_dict()
        }

class RepresentationSelector:
    @staticmethod
    def format_for_user(obj: SingulyarObject, prefs: Dict[str, bool]) -> Dict[str, Any]:
        out = {"text": str(obj.payload), "large_text": prefs.get("largeText", False)}
        if prefs.get("tts", False):
            out["tts_prompt"] = f"Объект от {obj.sender}: {obj.payload}"
        if obj.kind == IntentKind.VALUE_INTENT:
            out["disclaimer"] = "ВНИМАНИЕ: Намерение передачи ценности не является банковским переводом."
        return out

class RelationshipStore:
    def __init__(self):
        self.contacts: Dict[str, Dict[str, Any]] = {}

    def add_contact(self, name: str, trust_level: str = "added"):
        self.contacts[name] = {"name": name, "trust_level": trust_level, "addedAt": datetime.now(timezone.utc).isoformat()}

    def generate_invite_token(self) -> str:
        return "inv-" + hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()[:16]

class ConformanceTestSuite:
    @staticmethod
    def run():
        print("=== RUNNING CONFORMANCE SUITE v0.3 ===")
        # Test 1
        obj = SingulyarObject(IntentKind.MESSAGE, "Привет мир", "user1", "user2")
        assert len(obj.manifest.sha256_hash) == 64, "SHA-256 length error"
        print("[PASS] SHA-256 Manifest Calculation")

        # Test 2
        obj.delivery.transition_to(DeliveryState.LOCALLY_SAVED, "Saved")
        try:
            obj.delivery.transition_to(DeliveryState.READ, "Illegal jump")
            assert False, "Should fail on illegal transition"
        except ValueError:
            print("[PASS] State Machine Enforcement")

        # Test 3
        rep = RepresentationSelector.format_for_user(
            SingulyarObject(IntentKind.VALUE_INTENT, "100 credits", "A", "B"), {"largeText": True}
        )
        assert "disclaimer" in rep, "Missing value intent disclaimer"
        print("[PASS] Value Intent Disclaimer Requirement")

        # Test 4
        rel = RelationshipStore()
        token = rel.generate_invite_token()
        assert token.startswith("inv-"), "Invalid invite token"
        print("[PASS] Relationship Store Invitation Token")

        print("=== ALL CONFORMANCE TESTS PASSED ===")
        return True

if __name__ == "__main__":
    ConformanceTestSuite.run()
