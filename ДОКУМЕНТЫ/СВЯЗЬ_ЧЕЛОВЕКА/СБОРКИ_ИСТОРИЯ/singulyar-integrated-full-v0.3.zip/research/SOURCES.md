# SOURCES.md
## Реестр Источников и Стандартов
- W3C WebRTC 1.0 Specification
- WCAG 2.2 AA Accessibility Guidelines
- IETF RFC 4122 (UUID)
- FIPS PUB 180-4 (SHA-256)
