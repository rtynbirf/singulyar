# 03-PROTOCOL.md
## Протокол Объектной Передачи v0.3

Каждый объект содержит:
- `schema`: "singulyar.v0.1/object.json"
- `id`: UUID v4
- `kind`: IntentKind
- `createdAt`: ISO 8601 UTC
- `manifest`: { size_bytes, sha256, mime_type }
- `delivery`: { state, idempotency_key, audit_history }
