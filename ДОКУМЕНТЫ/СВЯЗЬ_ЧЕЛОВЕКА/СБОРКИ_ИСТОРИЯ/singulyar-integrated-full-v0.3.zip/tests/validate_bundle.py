#!/usr/bin/env python3
import os
import json
import hashlib

def validate():
    print("=== STARTING BUNDLE VALIDATION v0.3 ===")
    required_files = [
        "index.html",
        "СИНГУЛЯР_53_СВЯЗЬ_ЧЕЛОВЕКА.html",
        "singulyar_core.py",
        "README_RU.md",
        "CHANGELOG.md",
        "ERRORS_AND_ANTIPATTERNS.md",
        "spec/00-ARCHITECTURE.md",
        "spec/01-REQUIREMENTS.md",
        "integration/DOOR-INTEGRATION.md",
        "roadmap/ROADMAP.md",
        "tests/ACCEPTANCE.md"
    ]
    for rel_path in required_files:
        full_path = os.path.join(os.path.dirname(__file__), "..", rel_path)
        if not os.path.exists(full_path):
            print(f"[FAIL] Missing file: {rel_path}")
            return False
        size = os.path.getsize(full_path)
        print(f"[OK] {rel_path} ({size} bytes)")
    
    print("=== BUNDLE VALIDATION SUCCESSFUL ===")
    return True

if __name__ == "__main__":
    validate()
