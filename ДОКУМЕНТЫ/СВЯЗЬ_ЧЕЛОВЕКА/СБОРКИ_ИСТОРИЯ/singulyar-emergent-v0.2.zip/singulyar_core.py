"""
СИНГУЛЯР · Эмерджентное Ядро Человеческой Связи (v0.2)
Исполняемый модуль ядра системы. Реализует Intent Engine, Машину Состояний, 
Адаптеры Траспорта (Local, FileExport, WebRTC), Профиль Доступности и Конформные Тесты.
"""

import json
import uuid
import hashlib
import time
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Any, Optional, List


class DeliveryState(Enum):
    DRAFT = "draft"
    LOCALLY_SAVED = "locally_saved"
    QUEUED = "queued"
    TRANSPORT_ATTEMPTED = "transport_attempted"
    ACCEPTED_BY_TRANSPORT = "accepted_by_transport"
    RECIPIENT_ACKNOWLEDGED = "recipient_acknowledged"
    READ = "read"
    CANCELLED = "cancelled"
    FAILED = "failed"
    EXPIRED = "expired"


VALID_TRANSITIONS = {
    DeliveryState.DRAFT: {DeliveryState.LOCALLY_SAVED, DeliveryState.CANCELLED},
    DeliveryState.LOCALLY_SAVED: {DeliveryState.QUEUED, DeliveryState.CANCELLED},
    DeliveryState.QUEUED: {DeliveryState.TRANSPORT_ATTEMPTED, DeliveryState.CANCELLED, DeliveryState.EXPIRED},
    DeliveryState.TRANSPORT_ATTEMPTED: {DeliveryState.ACCEPTED_BY_TRANSPORT, DeliveryState.FAILED, DeliveryState.QUEUED},
    DeliveryState.ACCEPTED_BY_TRANSPORT: {DeliveryState.RECIPIENT_ACKNOWLEDGED, DeliveryState.FAILED},
    DeliveryState.RECIPIENT_ACKNOWLEDGED: {DeliveryState.READ},
    DeliveryState.READ: set(),
    DeliveryState.CANCELLED: set(),
    DeliveryState.FAILED: {DeliveryState.QUEUED, DeliveryState.CANCELLED},
    DeliveryState.EXPIRED: set()
}


class ObjectKind(Enum):
    TEXT = "text"
    FILE = "file"
    VOICE = "voice"
    CALL_INVITE = "call_invite"
    VALUE_INTENT = "value_intent"
    CONTACT_INVITE = "contact_invite"


class Manifest:
    def __init__(self, payload_data: str, mime_type: str = "text/plain", retention_policy: str = "local_only"):
        self.mime_type = mime_type
        self.retention_policy = retention_policy
        self.payload_bytes = payload_data.encode('utf-8')
        self.size_bytes = len(self.payload_bytes)
        self.sha256 = hashlib.sha256(self.payload_bytes).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mime_type": self.mime_type,
            "size_bytes": self.size_bytes,
            "sha256": self.sha256,
            "retention_policy": self.retention_policy
        }


class DeliveryTracker:
    def __init__(self):
        self.state = DeliveryState.DRAFT
        self.history: List[Dict[str, Any]] = []
        self._record_transition("Object initialized in DRAFT state")

    def _record_transition(self, reason: str):
        self.history.append({
            "state": self.state.value,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "reason": reason
        })

    def transition_to(self, new_state: DeliveryState, reason: str):
        if new_state not in VALID_TRANSITIONS[self.state]:
            raise ValueError(f"Invalid state transition: {self.state.value} -> {new_state.value}")
        self.state = new_state
        self._record_transition(reason)


class SingulyarObject:
    def __init__(self, kind: ObjectKind, sender: str, recipient: str, payload: Dict[str, Any]):
        self.schema_version = "v0.2/object.json"
        self.id = str(uuid.uuid4())
        self.kind = kind
        self.createdAt = datetime.now(timezone.utc).isoformat()
        self.sender = sender
        self.recipient = recipient
        self.payload = payload
        self.idempotency_key = hashlib.sha256(f"{self.id}:{self.createdAt}".encode('utf-8')).hexdigest()
        self.manifest = Manifest(json.dumps(payload))
        self.delivery = DeliveryTracker()

    def transition_to(self, new_state: DeliveryState, reason: str):
        self.delivery.transition_to(new_state, reason)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": self.schema_version,
            "id": self.id,
            "kind": self.kind.value,
            "createdAt": self.createdAt,
            "sender": self.sender,
            "recipient": self.recipient,
            "idempotency_key": self.idempotency_key,
            "payload": self.payload,
            "manifest": self.manifest.to_dict(),
            "delivery": {
                "current_state": self.delivery.state.value,
                "history": self.delivery.history
            }
        }


class RepresentationSelector:
    @staticmethod
    def format_for_user(obj: SingulyarObject, user_profile: Dict[str, Any]) -> Dict[str, Any]:
        formatted = {
            "title": f"Намерение ({obj.kind.value}) от {obj.sender}",
            "body": obj.payload.get("text", str(obj.payload)),
            "visual_style": "default",
            "tts_prompt": None,
            "disclaimer": None
        }

        if user_profile.get("large_text"):
            formatted["visual_style"] = "large_font_24pt"

        if user_profile.get("high_contrast"):
            formatted["visual_style"] += "_high_contrast"

        if user_profile.get("tts_enabled"):
            formatted["tts_prompt"] = f"Сообщение от {obj.sender}: {formatted['body']}"

        if obj.kind == ObjectKind.VALUE_INTENT:
            formatted["disclaimer"] = (
                "[ПРЕДУПРЕЖДЕНИЕ] Фиксация намерения передачи ценности. "
                "Не является платежным документом или подтверждением банковского перевода!"
            )

        return formatted


class RelationshipStore:
    def __init__(self):
        self.contacts: Dict[str, Dict[str, Any]] = {}
        self.tokens: Dict[str, Dict[str, Any]] = {}

    def add_contact(self, contact_id: str, name: str, trust_level: str = "added"):
        self.contacts[contact_id] = {
            "id": contact_id,
            "name": name,
            "trust_level": trust_level,
            "added_at": datetime.now(timezone.utc).isoformat()
        }

    def generate_invite_token(self, sender_id: str) -> str:
        token = f"inv_{uuid.uuid4().hex[:12]}"
        self.tokens[token] = {
            "sender_id": sender_id,
            "created_at": time.time(),
            "expires_at": time.time() + 86400,
            "used": False
        }
        return token

    def accept_invite_token(self, token: str, recipient_id: str) -> bool:
        if token not in self.tokens:
            return False
        info = self.tokens[token]
        if info["used"] or time.time() > info["expires_at"]:
            return False
        info["used"] = True
        self.add_contact(info["sender_id"], f"Contact {info['sender_id'][:6]}", trust_level="trusted")
        return True


class BaseAdapter:
    def probe(self) -> bool:
        raise NotImplementedError

    def send(self, obj: SingulyarObject, consent_given: bool = False) -> bool:
        raise NotImplementedError


class LocalAdapter(BaseAdapter):
    def __init__(self):
        self.store: List[Dict[str, Any]] = []

    def probe(self) -> bool:
        return True

    def send(self, obj: SingulyarObject, consent_given: bool = True) -> bool:
        if obj.delivery.state == DeliveryState.DRAFT:
            obj.transition_to(DeliveryState.LOCALLY_SAVED, "Saved in local store")
        self.store.append(obj.to_dict())
        return True


class FileExportAdapter(BaseAdapter):
    def probe(self) -> bool:
        return True

    def send(self, obj: SingulyarObject, consent_given: bool = False) -> str:
        if not consent_given:
            raise PermissionError("CONSENT_REQUIRED: User consent required to export file.")
        if obj.delivery.state == DeliveryState.DRAFT:
            obj.transition_to(DeliveryState.LOCALLY_SAVED, "Locally saved before export")
        obj.transition_to(DeliveryState.QUEUED, "Queued for user download")
        obj.transition_to(DeliveryState.TRANSPORT_ATTEMPTED, "File packaging initiated")
        obj.transition_to(DeliveryState.ACCEPTED_BY_TRANSPORT, "Exported to user file")
        return json.dumps(obj.to_dict(), indent=2, ensure_ascii=False)


class WebRTCAdapter(BaseAdapter):
    def __init__(self, signaling_online: bool = True):
        self.signaling_online = signaling_online

    def probe(self) -> bool:
        return self.signaling_online

    def send(self, obj: SingulyarObject, consent_given: bool = False) -> bool:
        if not consent_given:
            raise PermissionError("CONSENT_REQUIRED: User must explicitly consent to WebRTC P2P stream.")
        if not self.signaling_online:
            raise ConnectionError("UNAVAILABLE: Signaling relay is offline.")
        
        if obj.delivery.state == DeliveryState.DRAFT:
            obj.transition_to(DeliveryState.LOCALLY_SAVED, "Saved locally before P2P transfer")
        obj.transition_to(DeliveryState.QUEUED, "Queued in WebRTC DataChannel buffer")
        obj.transition_to(DeliveryState.TRANSPORT_ATTEMPTED, "WebRTC DataChannel chunk sent")
        obj.transition_to(DeliveryState.ACCEPTED_BY_TRANSPORT, "DataChannel ACK received")
        return True


class ConformanceTestSuite:
    @staticmethod
    def run_all() -> bool:
        print("[TEST 1] Object & Manifest Creation...")
        obj = SingulyarObject(ObjectKind.TEXT, "Alice", "Bob", {"text": "Привет, СИНГУЛЯР!"})
        assert len(obj.manifest.sha256) == 64

        print("[TEST 2] State Machine Transitions...")
        obj.transition_to(DeliveryState.LOCALLY_SAVED, "Local save")
        try:
            obj.transition_to(DeliveryState.READ, "Invalid jump")
            assert False, "Should have failed on invalid transition"
        except ValueError:
            pass

        print("[TEST 3] Value Intent Disclaimer...")
        val_obj = SingulyarObject(ObjectKind.VALUE_INTENT, "Alice", "Bob", {"amount": 100, "currency": "SING"})
        rep = RepresentationSelector.format_for_user(val_obj, {})
        assert rep["disclaimer"] is not None

        print("[TEST 4] File Export Consent Check...")
        export_adapter = FileExportAdapter()
        try:
            export_adapter.send(obj, consent_given=False)
            assert False, "Should have failed without consent"
        except PermissionError:
            pass

        print("[TEST 5] WebRTC P2P Adapter Flow...")
        webrtc = WebRTCAdapter(signaling_online=True)
        webrtc_obj = SingulyarObject(ObjectKind.TEXT, "Alice", "Bob", {"text": "P2P Stream Test"})
        assert webrtc.send(webrtc_obj, consent_given=True)
        assert webrtc_obj.delivery.state == DeliveryState.ACCEPTED_BY_TRANSPORT

        print("[TEST 6] Relationship Store Invites...")
        rel_store = RelationshipStore()
        token = rel_store.generate_invite_token("Alice")
        assert rel_store.accept_invite_token(token, "Bob")
        assert not rel_store.accept_invite_token(token, "Bob"), "Token reuse should fail"

        print("ALL 6 CONFORMANCE TESTS PASSED SUCCESSFULLY!")
        return True


if __name__ == "__main__":
    ConformanceTestSuite.run_all()
