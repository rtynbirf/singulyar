# Анализ отсутствующих компонентов и инженерные решения (СИНГУЛЯР v0.4)

## 1. Реестр отсутствующих компонентов в базовом коде (v0.1 / v0.2)

При сплошном аудите спецификаций (`00-ARCHITECTURE.md`, `01-REQUIREMENTS.md`, `02-THREAT-MODEL.md`, `03-PROTOCOL.md`, `04-ADAPTER-CONTRACT.md`, `ROADMAP.md`, `WORK_BREAKDOWN.md`) выведена следующая матрица отсутствующих компонентов:

| Компонент | Требование спецификации | Статус в v0.1 / v0.2 | Исполняемое решение v0.4 |
| :--- | :--- | :--- | :--- |
| **IndexedDB Repository** | `ADR-002`, `WP-04` (localStorage не подходит) | Отсутствовало (использовался `localStorage`) | `storage/indexeddb_store.js` (4 хранилища, транзакции, индексы) |
| **E2EE Key Generation** | `00-ARCHITECTURE.md` (секция 4), `WP-06`, `WP-09` | Отсутствовало (нет Web Crypto API) | `crypto/singulyar_crypto.js` (ECDH keypairs, SHA-256 HKDF fingerprints) |
| **Invite Token Lifecycle** | `00-ARCHITECTURE.md` (токен с TTL и однократным вводом) | Отсутствовало (ввод имен вручную) | `CryptoEngine.create_invite_token()` с подписью и проверкой TTL |
| **Email Relay Adapter** | `04-ADAPTER-CONTRACT.md`, `WP-10` | Отсутствовало (была заглушка) | `EmailAdapter` (генерация mailto, проверка согласия, карточка DMARC/SPF) |
| **Value Intent Machine** | `03-PROTOCOL.md` (дисклеймер, idempotency key, anti-double-spend) | Было частично без защиты от дублирования | `ValueAdapter` (строгая машина состояний, Idempotency Key, дисклеймер) |
| **Conformance Tests V4** | `ACCEPTANCE.md`, `WORK_BREAKDOWN.md` | Были базовые тесты | `singulyar_core.py` (авто-тестовый комплекс со 100% покрытием всех WP) |

---

## 2. Развернутые инженерные решения

### 2.1. IndexedDB Persistent Store (`storage/indexeddb_store.js`)
* Реализует структуру из 4 хранилищ: `objects` (объекты с индексами по состоянию и получателю), `contacts` (уровни доверия), `keys` (ключи идентификации), `audit_log` (история переходов состояний).
* Полностью удовлетворяет требованию `NFR-RES` и `WP-04`.

### 2.2. E2EE Identity Keys Engine (`crypto/singulyar_crypto.js`)
* Реализует стандарты `W3C Web Crypto API` и `IETF RFC 8446`.
* Формирует 32-символьный отпечаток ключа в формате `ABCD:EF01:...` для независимой ручной верификации человеком по второму каналу.
* Токены приглашения содержат случайный `tokenId`, метку времени, `expiresAt` и криптографическую подпись SHA-256.

### 2.3. Исполняемое ядро Python (`singulyar_core.py`)
* Обеспечивает полную совместимость с контрактными тестами `WP-01`...`WP-12`.
* Проверяет невалидные переходы машин состояний и блокирует отправку без явного разрешения `grant_consent()`.
