/**
 * СИНГУЛЯР IndexedDB Persistent Storage (storage/indexeddb_store.js)
 * Production-хранилище, заменяющее устаревший localStorage из v0.1
 */

class SingulyarStore {
    constructor(dbName = 'SingulyarDB', dbVersion = 1) {
        this.dbName = dbName;
        this.dbVersion = dbVersion;
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // 1. Objects Store (сообщения, файлы, намерения)
                if (!db.objectStoreNames.contains('objects')) {
                    const objectStore = db.createObjectStore('objects', { keyPath: 'id' });
                    objectStore.createIndex('kind', 'kind', { unique: false });
                    objectStore.createIndex('createdAt', 'createdAt', { unique: false });
                    objectStore.createIndex('recipient', 'recipient', { unique: false });
                    objectStore.createIndex('state', 'delivery.state', { unique: false });
                }

                // 2. Contacts Store (отношения и доверие)
                if (!db.objectStoreNames.contains('contacts')) {
                    const contactStore = db.createObjectStore('contacts', { keyPath: 'id' });
                    contactStore.createIndex('fingerprint', 'fingerprint', { unique: true });
                    contactStore.createIndex('trustLevel', 'trustLevel', { unique: false });
                }

                // 3. Identity Keys Store (ключи E2EE)
                if (!db.objectStoreNames.contains('keys')) {
                    db.createObjectStore('keys', { keyPath: 'keyId' });
                }

                // 4. Audit Log Store (история переходов состояний)
                if (!db.objectStoreNames.contains('audit_log')) {
                    const auditStore = db.createObjectStore('audit_log', { keyPath: 'auditId', autoIncrement: true });
                    auditStore.createIndex('objectId', 'objectId', { unique: false });
                }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(this.db);
            };

            request.onerror = (event) => {
                reject('IndexedDB initialization failed: ' + event.target.error);
            };
        });
    }

    async saveObject(singulyarObject) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['objects', 'audit_log'], 'readwrite');
            const objectsStore = tx.objectStore('objects');
            const auditStore = tx.objectStore('audit_log');

            objectsStore.put(singulyarObject);

            // Audit entry
            auditStore.add({
                objectId: singulyarObject.id,
                state: singulyarObject.delivery.state,
                timestamp: new Date().toISOString(),
                evidence: singulyarObject.delivery.auditLog.slice(-1)[0]?.evidence || 'state_update'
            });

            tx.oncomplete = () => resolve(true);
            tx.onerror = (e) => reject('Transaction failed: ' + e.target.error);
        });
    }

    async getObjects() {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['objects'], 'readonly');
            const store = tx.objectStore('objects');
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject('Failed to read objects');
        });
    }

    async clearAllData() {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(['objects', 'contacts', 'keys', 'audit_log'], 'readwrite');
            tx.objectStore('objects').clear();
            tx.objectStore('contacts').clear();
            tx.objectStore('keys').clear();
            tx.objectStore('audit_log').clear();
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject('Failed to clear stores');
        });
    }
}

if (typeof module !== 'undefined') {
    module.exports = { SingulyarStore };
}
