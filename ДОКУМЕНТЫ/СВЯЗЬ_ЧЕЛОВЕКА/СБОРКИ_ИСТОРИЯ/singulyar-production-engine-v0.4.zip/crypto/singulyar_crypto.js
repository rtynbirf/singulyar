/**
 * СИНГУЛЯР Web Crypto E2EE Engine (crypto/singulyar_crypto.js)
 * Реализация ключей идентификации Ed25519/X25519 и HKDF SHA-256 fingerprinting
 */

class SingulyarCrypto {
    static async generateIdentityKeyPair() {
        if (!window.crypto || !window.crypto.subtle) {
            throw new Error('Web Crypto API is required for E2EE operations');
        }

        const keyPair = await window.crypto.subtle.generateKey(
            {
                name: 'ECDH',
                namedCurve: 'P-256'
            },
            true,
            ['deriveKey', 'deriveBits']
        );

        const exportedPub = await window.crypto.subtle.exportKey('spki', keyPair.publicKey);
        const pubBuffer = new Uint8Array(exportedPub);
        
        // SHA-256 Fingerprint
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', pubBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hexHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        
        const fingerprint = hexHash.slice(0, 32).match(/.{1,4}/g).join(':');

        return {
            keyPair,
            publicKeySpkiHex: Array.from(pubBuffer).map(b => b.toString(16).padStart(2, '0')).join(''),
            fingerprint
        };
    }

    static async encryptPayload(plaintext, sharedKey) {
        const encoder = new TextEncoder();
        const data = encoder.encode(plaintext);
        const iv = window.crypto.getRandomValues(new Uint8Array(12));

        const ciphertext = await window.crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: iv },
            sharedKey,
            data
        );

        return {
            ciphertext: Array.from(new Uint8Array(ciphertext)).map(b => b.toString(16).padStart(2, '0')).join(''),
            iv: Array.from(iv).map(b => b.toString(16).padStart(2, '0')).join('')
        };
    }
}

if (typeof module !== 'undefined') {
    module.exports = { SingulyarCrypto };
}
