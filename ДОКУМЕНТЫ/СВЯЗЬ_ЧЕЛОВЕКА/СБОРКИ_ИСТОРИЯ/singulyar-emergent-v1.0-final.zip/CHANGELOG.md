# CHANGELOG · СИНГУЛЯР

## [v1.0-final] - 2026-10-14
### Добавлено
- **Полнофункциональный WebRTC DataChannel P2P Адаптер** с ручным и QR/URI сигналингом, поддержкой STUN/TURN и отправкой квитирований ACK.
- **Web Crypto API E2EE Engine**: Генерация пар ECDH P-256, расчет 32-символьного отпечатка SHA-256, шифрование AES-256-GCM.
- **IndexedDB Persistent Storage v1.0**: Параллельный доступ через Web Locks API, StorageManager persistence, транзакционный журнал аудита.
- **Интеграция в «Дом Дверей»**: Минимальный безопасный патч для `index.html` с подключением `·53 СВЯЗЬ ЧЕЛОВЕКА`.
- **Автоматический Conformance Test Suite v1.0**: 100% покрытие рабочих пакетов WP-01…WP-12.
