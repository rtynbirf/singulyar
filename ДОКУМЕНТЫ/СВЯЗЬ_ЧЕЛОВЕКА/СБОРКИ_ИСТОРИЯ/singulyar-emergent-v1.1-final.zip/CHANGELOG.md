# CHANGELOG · СИНГУЛЯР

## [v1.1] - 2026-10-14
### Добавлено
- **GitHub Issue Templates**: Добавлены шаблоны `bug_report.md`, `feature_request.md` и конфигурация `config.yml`.
- **GitHub Actions PR Automation**: Добавлен рабочий процесс `.github/workflows/pr_check.yml` для автоматического запуска Conformance Test Suite и проверки целостности комплекта при создании Pull Request.
- **GitHub Actions Deployment**: Интегрирован процесс автоматического деплоя на GitHub Pages `.github/workflows/deploy.yml`.

## [v1.0-final] - 2026-10-14
### Добавлено
- **Полнофункциональный WebRTC DataChannel P2P Адаптер** с ручным сигналингом и отправкой квитирований ACK.
- **Web Crypto API E2EE Engine**: Генерация пар ECDH P-256, расчет 32-символьного отпечатка SHA-256, шифрование AES-256-GCM.
- **IndexedDB Persistent Storage v1.0**: Параллельный доступ через Web Locks API, StorageManager persistence, транзакционный журнал аудита.
- **Интеграция в «Дом Дверей»**: Минимальный безопасный патч для `index.html` с подключением `·53 СВЯЗЬ ЧЕЛОВЕКА`.
- **Автоматический Conformance Test Suite v1.0**: 100% покрытие рабочих пакетов WP-01…WP-12.
